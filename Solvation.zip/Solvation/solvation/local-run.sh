#!/bin/bash
set -e

# Create folder for analysis
mkdir -p dhdl

# Loop over 21 lambda states
for state in $(seq 0 20)
do
    # Create folder for each lambda state
    DIRNAME="lambdastate${state}"
    mkdir -p "$DIRNAME"

    # Copy required input files into the lambda folder
    cp inputs/equilibration.mdp inputs/production.mdp conf.gro topol.top "$DIRNAME"/
    cp -r ff "$DIRNAME"/
    cp h2o.itp "$DIRNAME"/

    cd "$DIRNAME"

        # Update the value of init-lambda-state in both mdp files
        newline="init-lambda-state = ${state}"
        sed -i -E "s/^init-lambda-state[[:space:]]*=.*/${newline}/" equilibration.mdp
        sed -i -E "s/^init-lambda-state[[:space:]]*=.*/${newline}/" production.mdp

        # Run equilibration
        gmx grompp -f equilibration.mdp -c conf.gro -p topol.top -o equilibration -pp equilibration -po equilibration -maxwarn 1
        #gmx mdrun -v -deffnm equilibration -nt 4
	mpirun -np 16 gmx mdrun -v -deffnm equilibration

        # Run production
        gmx grompp -f production.mdp -c equilibration.gro -p topol.top -o production -pp production -po production -maxwarn 1
        #gmx mdrun -v -deffnm production -nt 4
	mpirun -np 16 gmx mdrun -v -deffnm production


    cd ..

    # Create symbolic link for analysis
    if [ -f "$DIRNAME/production_dhdl.xvg" ]; then
        ln -sf "../$DIRNAME/production_dhdl.xvg" "dhdl/md${state}.xvg"
    elif [ -f "$DIRNAME/production.xvg" ]; then
        ln -sf "../$DIRNAME/production.xvg" "dhdl/md${state}.xvg"
    else
        echo "[WARN] dhdl file not found in $DIRNAME"
    fi

done
